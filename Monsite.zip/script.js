function showMessage() {
    document.getElementById("message").innerText = "Le déploiement fonctionne parfaitement ! ";
}
